package lhtchePrac;

public class AcornCalculator implements Calculator{

	@Override
	public int add(int su1, int su2) {
		// TODO Auto-generated method stub
		return su1 + su2;
	}

	@Override
	public int minus(int su1, int su2) {
		// TODO Auto-generated method stub
		return su1 - su2;
	}

	@Override
	public int multiply(int su1, int su2) {
		// TODO Auto-generated method stub
		return su1 * su2;
	}

	@Override
	public int divide(int su1, int su2) {
		// TODO Auto-generated method stub
		return su1 / su2;
	}

}
