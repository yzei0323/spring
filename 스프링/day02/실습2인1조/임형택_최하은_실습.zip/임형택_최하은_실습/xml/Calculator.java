package lhtchePrac;

public interface Calculator {
	
	int add(int su1, int su2);
	
	int minus(int su1, int su2);
	
	int multiply(int su1, int su2);
	
	int divide(int su1, int su2);
	
}
