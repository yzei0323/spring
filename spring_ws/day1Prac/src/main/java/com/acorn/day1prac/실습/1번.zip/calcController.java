package com.acorn.day1prac;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

@Controller
public class calcController {

	@RequestMapping(value = "/calcinput", method = RequestMethod.GET)
	public String calcForm() {
		return "calcinput";
	}

	@RequestMapping(value = "/calcinput", method = RequestMethod.POST)
	public String calc(@RequestParam("num1") int num1, @RequestParam("num2") int num2,
			@RequestParam("operator") String operator, Model model) {

		int result = 0;
		String sachic = "";

		switch (operator) {
		case "add":
			result = num1 + num2;
			sachic = "+";
			break;
		case "sub":
			result = num1 - num2;
			sachic = "-";
			break;
		case "mul":
			result = num1 * num2;
			sachic = "*";
			break;
		case "div":
			result = num1 / num2;
			sachic = "/";
			break;
		}

		model.addAttribute("num1", num1);
		model.addAttribute("num2", num2);
		model.addAttribute("operator", sachic);
		model.addAttribute("result", result);
		return "calcresult";
	}
}
